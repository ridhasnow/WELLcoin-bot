const { Telegraf } = require("telegraf");
const express = require("express");
const path = require("path");
const app = express();

const bot = new Telegraf("PASTE_YOUR_BOT_TOKEN_HERE");

bot.start((ctx) => {
  ctx.reply("Welcome to the WELLcoin game 💰! Tap the buttons below to start mining.");
});

bot.command("me", (ctx) => {
  ctx.reply("🔍 Profile:\nBalance: 0.2 WELLcoin\nStatus: Poor");
});

bot.launch();

app.use(express.static("public"));
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(3000, () => {
  console.log("Web server running on port 3000");
});
